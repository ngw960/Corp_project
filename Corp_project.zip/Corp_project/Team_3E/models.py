from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
class UsersManager(BaseUserManager):
    def create_user(self, user_id, password=None, **extra_fields):
        """사용자 생성 메서드"""
        if not user_id:
            raise ValueError("The User ID must be set")
        user = self.model(user_id=user_id, **extra_fields)
        user.set_password(password)  # 비밀번호 해시화
        user.save(using=self._db)
        return user
    def create_superuser(self, user_id, password=None, **extra_fields):
        """관리자 사용자 생성 메서드"""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(user_id, password, **extra_fields)
class Users(AbstractBaseUser):
    user_id  = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=200)
    name     = models.CharField(max_length=50)
    email    = models.EmailField(max_length=50, unique=True)
    USERNAME_FIELD = 'user_id'
    REQUIRED_FIELDS = ['name', 'email']
    objects = UsersManager()  # 사용자 매니저 설정
class Character (models.Model):
    name        = models.CharField(max_length=100)                # 캐릭터 이름
    description = models.TextField(null=True, blank=True)  # 캐릭터 설명 (NULL 가능)
    level       = models.IntegerField(default=1)                  # 캐릭터 레벨 (기본값 1)
    health      = models.IntegerField(default=100)               # 캐릭터 건강 상태 (기본값 100)
    user        = models.ForeignKey(Users, on_delete=models.CASCADE,related_name='character')  # Users 테이블과의 관계
    def __str__(self):
        return self.name  # 캐릭터 이름으로 출력
